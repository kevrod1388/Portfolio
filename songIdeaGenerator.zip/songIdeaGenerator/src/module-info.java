/**
 * 
 */
/**
 * 
 */
module songIdeaGenerator {
	requires java.desktop;  // This unlocks sound APIs
}