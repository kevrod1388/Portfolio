package songIdeaGenerator;

import javax.sound.sampled.*;

public class SineBeepTest {
    public static void main(String[] args) {
        try {
            int sampleRate = 8000;  // Low for simplicity (8kHz)
            int freq = 440;         // A4 note in Hz
            int i = 0;              // Angle counter

            // Audio setup: Format for 8-bit mono
            AudioFormat format = new AudioFormat(sampleRate, 8, 1, true, false);
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
            SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info);
            line.open(format);
            line.start();

            // Your loop: Generate & play sine chunks (runs ~5s; kill with Ctrl+C for infinite)
            long endTime = System.currentTimeMillis() + 5000;  // Stop after 5s
            while (System.currentTimeMillis() < endTime) {
                double samplingInterval = (double) sampleRate / freq;
                double angle = (2.0 * Math.PI * i) / samplingInterval;
                byte toPlay = (byte) (Math.sin(angle) * 127);  // Scale to byte (-128 to 127)

                byte[] data = new byte[1024];
                for (int j = 0; j < data.length; j++) {
                    data[j] = toPlay;  // Fill buffer with current sample (simple tone)
                }
                line.write(data, 0, data.length);
                i++;
            }

            line.drain();  // Play out remaining audio
            line.close();
            System.out.println("Beep complete!");  // Confirmation

        } catch (Exception e) {
            e.printStackTrace();  // Debug: Print errors
        }
    }
}