package songIdeaGenerator;

public class MelodyData {
	int[] notes;
	int[] durations;
	public MelodyData(int[] n, int[] d){
		notes = n;
		durations = d;
	}
}