package songIdeaGenerator;

import javax.swing.*; // TODO 1: Add other Swing imports if needed (e.g., JPanel, FlowLayout)
import java.awt.event.*; // TODO 2: Add for ActionListener if not auto-imported

public class MelodyGUI extends JFrame { // TODO 3: Extend JFrame for window base
    private MelodyGenerator gen = new MelodyGenerator(); // TODO 4: Your gen instance

    public MelodyGUI() {
        // TODO 5: Set title (setTitle("..."))
    	setTitle("Song Idea Generator");
        // TODO 6: Set size (setSize(width, height))
    	setSize(300,200);
        // TODO 7: Set close operation (setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE))
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // TODO 8: Create JComboBox for moods (new JComboBox<>(new String[]{"happy", "neutral", "sad"}))
        JComboBox<String> moodCombo = new JComboBox<>(new String[]{"happy", "neutral", "sad"}); // Fill options in TODO 8

        // TODO 9: Create JButton (new JButton("Generate & Play"))
        JButton playBtn = new JButton("Generate & Play"); // Set text in TODO 9
        
        JLabel feedback = new JLabel();
        // TODO 10: Add ActionListener to button (playBtn.addActionListener(e -> { ... }))
        playBtn.addActionListener(e -> {
            // TODO 11: Get mood string from combo ( (String) moodCombo.getSelectedItem() )
        	String mood = (String) moodCombo.getSelectedItem();
  

            // TODO 12: Gen MelodyData data = gen.generateNotes(8, mood) (longer for demo)
            MelodyData data = gen.generateNotes(8,  mood); // Gen in TODO 12

            // TODO 13: gen.playMelody(data); (play it)
            gen.playMelody(data);
            
           // JLabel feedback = new JLabel();
            feedback.setText("Generated: " + java.util.Arrays.toString(data.notes));
           
            revalidate();
            
        });

        // TODO 14: Add components to layout (JPanel panel = new JPanel(); panel.add(moodCombo); panel.add(playBtn); add(panel);)
       // add(new JPanel()); // Placeholder�add in TODO 14
        JPanel panel = new JPanel();
        panel.add(moodCombo);
        panel.add(playBtn);
        panel.add(feedback);
        add(panel);

        // TODO 15: setVisible(true); (show window)
        setVisible(true);
    }

    public static void main(String[] args) {
        // TODO 16: SwingUtilities.invokeLater(() -> new MelodyGUI()); (safe launch on EDT)
    	SwingUtilities.invokeLater(() -> new MelodyGUI());
    }
}