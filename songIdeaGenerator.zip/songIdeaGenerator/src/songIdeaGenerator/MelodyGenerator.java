package songIdeaGenerator;


import javax.sound.midi.*; // For later playback
import java.util.Random;
import java.util.Arrays;
import java.io.File; // For new File("TimGM6mb.sf2")


public class MelodyGenerator{
	private int[] scale = {60, 62, 64, 65, 67, 69, 71};
	private Random rand = new Random();



public MelodyData generateNotes(int length, String mood) { // TODO 5: Return type to MelodyData (auto-visible)
    int[] notes = new int[length];
    int[] durations = new int[length]; // Ticks per note
    boolean isHappy = "happy".equals(mood);
    for (int i = 0; i < length; i++) {
        int index = rand.nextInt(scale.length);
        if (isHappy) {
            index = (index + 3) % scale.length;
        }
        notes[i] = scale[index];
        // TODO 6: durations[i] = rand.nextBoolean() ? 96 : 48; // Random quarter/eighth
        durations[i] = rand.nextBoolean() ? 96 : 48;
        System.out.println("Note " + i + ": " + notes[i] + " (dur: " + durations[i] + ")");
    }
    return new MelodyData(notes, durations); // TODO 7: New instance (notes, durations)
}

    public void playMelody(MelodyData data) {
        try {
            // Synth setup with soundfont (direct mode�no Sequencer)
            Synthesizer synth = MidiSystem.getSynthesizer();
            synth.open();
            System.out.println("Synth opened: Max polyphony = " + synth.getMaxPolyphony());

            // Load soundfont
            try {
                File sfFile = new File("TimGM6mb.sf2");
                System.out.println("Soundfont exists: " + sfFile.exists() + " at path: " + sfFile.getAbsolutePath());
                Soundbank soundbank = MidiSystem.getSoundbank(sfFile);
                if (soundbank != null) {
                    synth.loadAllInstruments(soundbank);
                    Instrument piano = soundbank.getInstruments()[0]; // Piano (or [25] for guitar)
                    synth.loadInstrument(piano);
                    System.out.println("Loaded soundfont piano: " + piano.getName());
                } else {
                    System.out.println("Soundbank load failed�file invalid or missing");
                }
            } catch (Exception sbErr) {
                System.out.println("Soundfont snag: " + sbErr.getMessage() + " � Using default");
            }

            // Get receiver for direct sends
            Receiver receiver = synth.getReceiver();
            MidiChannel channel = synth.getChannels()[0]; // Channel 0
            channel.controlChange(7, 127); // Max volume

            // Send events directly (no sequence/track)
            long currentTime = 0;
            for (int i = 0; i < data.notes.length; i++) {
            	int note = data.notes[i];
            	int dur = data.durations[i];
                ShortMessage onMsg = new ShortMessage();
                onMsg.setMessage(ShortMessage.NOTE_ON, 0, note, 127); // Max loud
                receiver.send(onMsg, currentTime); // Send at current time

                ShortMessage offMsg = new ShortMessage();
                offMsg.setMessage(ShortMessage.NOTE_OFF, 0, note, 0);
                receiver.send(offMsg, currentTime + dur); // Off after quarter note

                currentTime += dur;
                System.out.println("Sent event for note " + note + " at " + currentTime); // Trace
                Thread.sleep(200); // Short pause for note duration (quarter @90BPM ~667ms, but direct send is instant)
            }

            Thread.sleep(1000); // Buffer for last note fade
            receiver.close();
            synth.close();

            System.out.println("Melody played! Notes: " + Arrays.toString(data.notes));
        } catch (Exception e) {
            System.out.println("Playback snag: " + e.getMessage());
            e.printStackTrace();
        }
    }
    


    public static void main(String[] args) {
    	
        MelodyGenerator gen = new MelodyGenerator();
     //   gen.playMelody(new int[]{60}); System.out.println("Single C test done.");
       
        int[] singleNotes = new int[] {60};
        int[] singleDurs = new int[singleNotes.length];
        for(int i = 0; i < singleDurs.length; i++) {
        	singleDurs[i] = 96;
        }
        
        MelodyData singleData = new MelodyData(singleNotes, singleDurs);
        gen.playMelody(singleData);
        System.out.println("Single C test done.");
        
        MelodyData testData = gen.generateNotes(4, "happy"); // Short test
        System.out.println("Generated: " + java.util.Arrays.toString(testData.notes));
        gen.playMelody(testData); // Uncomment when ready
        
        MelodyData neutralData = gen.generateNotes(4, "neutral"); // No bias
        System.out.println("Neutral: " + java.util.Arrays.toString(neutralData.notes));
        gen.playMelody(neutralData); // Bonus: Play this too for comparison

        MelodyData happyData = gen.generateNotes(4, "happy");
        System.out.println("Happy: " + java.util.Arrays.toString(happyData.notes));
        gen.playMelody(happyData); // And this�full trio!
        
     // Quick octave test: C4 to C5 leap
        int[] octaveNotes = {60, 72};
        int[] octaveDurs = new int[octaveNotes.length];
        for(int i = 0; i < octaveDurs.length; i++) {
        	octaveDurs[i] = 96;
        }
        MelodyData octaveData = new MelodyData(octaveNotes, octaveDurs);
        System.out.println("Octave test starting...");
        gen.playMelody(octaveData);
        System.out.println("Octave test done!");
       
        
        MelodyData data = gen.generateNotes(4,  "happy");
        System.out.println("Notes: " + java.util.Arrays.toString(data.notes) + ", Durs: " + java.util.Arrays.toString(data.durations));
    }
    }
