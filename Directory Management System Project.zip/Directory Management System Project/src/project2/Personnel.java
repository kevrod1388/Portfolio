package project2;
import java.util.*;

public class Personnel {
	
	public ArrayList<Person> personList;

	public Personnel() {
	   personList = new ArrayList<Person>();
	}

	public void addPersonnel(Person p)
	{
		personList.add(p);
	}

	//return true if a person in the personList has this firstName and lastName
	//else return false
	public boolean checkIfPersonnelExists(String firstName, String lastName) {
		
		  for(int i =0; i < personList.size(); i++)
			  {
			  //found person
				if( personList.get(i).getFirst().equals(firstName) && personList.get(i).getLast().equals(lastName))
				{
					  System.out.println("found");

					System.out.println(personList.get(i).getFirst());
					System.out.println(personList.get(i).getMiddle());
					System.out.println(personList.get(i).getLast());
					System.out.println(personList.get(i).getType());
					return true;
			    }
				
			  }
		  System.out.println("not found");
		return false;
	}
	
	public int getTotalObjects() {
		return personList.size();
	}
	
	public void addPersonell(String lastN, String firstN, String middleN, int empID, int salary) {
		  Employee e1  = new Employee(lastN, firstN, middleN, empID, salary);
			
			
		  addPersonnel(e1);
	}
}
