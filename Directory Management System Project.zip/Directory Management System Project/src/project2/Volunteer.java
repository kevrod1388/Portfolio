package project2;

public class Volunteer extends Employee {
	

	public Volunteer(String last, String first, String middle, int id, double sal) {
		super(last, first, middle, id, sal);
	
	}
	
	public String getType() {
		return "Volunteer";
	}


}
