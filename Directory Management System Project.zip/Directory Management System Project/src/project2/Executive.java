package project2;

public class Executive extends Employee {

	public Executive(String last, String first, String middle, int id, double sal) {
		super(last, first, middle, id, sal);
	
	}

	public String getType() {
		return "Executive";
	}

	

}
