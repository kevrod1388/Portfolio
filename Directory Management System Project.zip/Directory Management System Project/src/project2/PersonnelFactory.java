package project2;

public class PersonnelFactory {
	
	
	public static Person createPersonnel(String type, String lastN, String firstN, String middleN, int empID, double salary) {
					  
		  switch(type) {
		  	case "E":
		  		return new Executive(lastN, firstN, middleN, empID, salary);
		  	case "S":
		  		return new Security(lastN, firstN, middleN, empID, salary);
		  	case "V":
		  		return new Volunteer(lastN, firstN, middleN, empID, salary);
		  	case "X":
		  		return new Employee(lastN, firstN, middleN, empID, salary);
		  	case "P":
		  		return new Person(lastN, firstN, middleN);

		  
		  }
			return null;
	}

}
