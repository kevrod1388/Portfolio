package project2;
import java.util.Scanner;

public class PersonnelDirectory {
	
	 public static void main(String[] args)
	   {
	             Personnel per = new Personnel();
				 // totalObjects total = new totalObjects();
				  Scanner scan = new Scanner(System.in);
				  String firstN, lastN, middleN;
				  int empID;
				  double salary;
	              int choice = -1;


	      do{


	          System.out.println("Welcome to the Personnel Directory Management System");
	          System.out.println("====================================================");

	          System.out.println("\n\n\t 1. Add Personel");
	          System.out.println("\n\t 2. Find Personel");
	          System.out.println("\n\t 3. Print Names");
	          System.out.println("\n\t 4. Number of Entries in the Directory");

	          System.out.println("\n\t Select one of the options above (1, 2, 3, 4)");
	          choice = scan.nextInt();
	          scan.nextLine();

	          switch(choice)
	          {
				  case 1:
					  System.out.println("Enter first name: ");
					  firstN = scan.nextLine();
					  System.out.println("Enter last name: ");
					  lastN = scan.nextLine();
					  System.out.println("Enter middle name: ");
					  middleN = scan.nextLine();
	
					  System.out.println("Enter employee id : ");
					  empID = scan.nextInt();
					  System.out.println("Enter base salary" );
					  salary = scan.nextDouble();
					  scan.nextLine();
					  
					  System.out.println("Enter Employee Type");
					  System.out.println("Select E for Executive:");
					  System.out.println("Select S for Security:" );
					  System.out.println("Select V for Volunteer:" );
					  System.out.println("Select X for Employee:" );
					  System.out.println("Select P for Person:" );

					  String type = scan.nextLine();
					  Person employee = PersonnelFactory.createPersonnel(type, lastN, firstN, middleN, empID, salary);
					  System.out.println(employee.getType());
					  per.addPersonnel(employee);
	
					  break;

				  case 2:

				  System.out.println("Enter first name : ");
				  firstN = scan.nextLine();

				  System.out.println("Enter last name : ");
				  lastN = scan.nextLine();
				  
				  boolean found = per.checkIfPersonnelExists(firstN, lastN);
				  if(found == false) { //not found person
					  per.addPersonell(lastN, firstN, " ", 0, 0);
				}


	              break;

				  case 3:

				  System.out.println("Enter the order 0: first, middle,  last, 1: first, last, middle, 2: last, first , middle ");
				  int order = scan.nextInt();
				  for(int i=0; i<per.personList.size(); i++)
				  {
					  if(order == 0)
					   {
					      System.out.println(per.personList.get(i).getFirst() + "  " + per.personList.get(i).getMiddle() + "  " + per.personList.get(i).getLast());

					   }else if(order == 1)
					       {

					       System.out.println(per.personList.get(i).getFirst() + " ," + per.personList.get(i).getLast() + " " + per.personList.get(i).getMiddle());

					       }
					       else if(order == 2)
						   	       {

						   	       System.out.println(per.personList.get(i).getLast() + " ," + per.personList.get(i).getFirst() + " " + per.personList.get(i).getMiddle());

					       }
					 // per.personList.get(i).printName(order);
				  }

	               break;

				  case 4:
				  System.out.println("Total Entries : " + per.getTotalObjects());

	               break;

			  }

			 } while(true);


	  }

}
