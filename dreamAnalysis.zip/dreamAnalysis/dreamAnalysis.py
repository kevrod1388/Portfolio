# TODO 1: Import the pipeline class from transformers
from transformers import pipeline


def analyze_dream_entry(entry_text):
    print(f"DEBUG: I received this text -> '{entry_text}'")
    # TODO 2: Initialize a sentiment pipeline with the "sentiment-analysis" model name
    sentiment = pipeline("sentiment-analysis")
    # TODO 3: Call the pipeline on entry_text and assign the result to a variable
    result = sentiment(entry_text)
    # TODO 4: Create an empty list for symbols
    symbols = []
    # TODO 5: Use if-statements to check entry_text.lower() for keywords like 'water', 'fly', 'fall'; append strings like "water (emotion symbol)" to the list
    if 'keyword' in entry_text.lower():
        symbols.append("keyword (meaning)")
    if 'water' in entry_text.lower():
        symbols.append("water (emotion symbol)")
    if 'fly' in entry_text.lower():
        symbols.append("freedom symbol")
    if 'fall' in entry_text.lower():
        symbols.append("letting go symbol")
    if 'chase' in entry_text.lower():
        symbols.append("avoidance symbol")
    if 'teeth' in entry_text.lower():
        symbols.append("anxiety symbol")
    if 'naked' in entry_text.lower():
        symbols.append("vulnerability symbol")
    if 'house' in entry_text.lower():
        symbols.append("subconcious symbol")
    if 'car' in entry_text.lower():
        symbols.append("desire symbol")


# TODO 6: Print the sentiment label and score from result[0] using an f-string (round score to 2 decimals)
    print(f"Sentiment: {result[0]['label']} (score: {round(result[0]['score'], 2)})")
    #print(", ".join(symbols))
# TODO 7: Print the symbols list joined by commas
    print(", ".join(symbols))

# TODO 8: Under if __name__ == "__main__":, get user input for the dream entry and call analyze_dream_entry on it
if __name__ == "__main__":
    dream = input("Enter your dream: ")
    analyze_dream_entry(dream)
    
