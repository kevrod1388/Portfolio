package Chapter2StateMachines.MinersSonOwnedStates;


import static Chapter2StateMachines.EntityNames.GetNameOfEntity;
import static common.Time.CrudeTimer.Clock;
import static common.misc.ConsoleUtils.SetTextColor;
import static common.misc.ConsoleUtils.cout;
import static common.misc.utils.RandFloat;
import static common.windows.BACKGROUND_RED;
import static common.windows.FOREGROUND_BLUE;
import static common.windows.FOREGROUND_GREEN;
import static common.windows.FOREGROUND_INTENSITY;
import static common.windows.FOREGROUND_RED;

import Chapter2StateMachines.MinersSon;
import Chapter2StateMachines.State;
import common.Messaging.Telegram;


public class SonGlobalState extends State<MinersSon>{
	
	  static final SonGlobalState instance = new SonGlobalState();

	    private SonGlobalState() {
	    }

	    //copy ctor and assignment should be private
	    @Override
	    protected Object clone() throws CloneNotSupportedException {
	        throw new CloneNotSupportedException("Cloning not allowed");
	    }

	    public static SonGlobalState Instance() {
	        return instance;
	    }

	    @Override 
	    public void Enter(MinersSon son) {
	    	
	    }
	    
	    
	    @Override
	    public void Execute(MinersSon son) {
	    	 if ((RandFloat() < 0.1)
	                 && !son.GetFSM().isInState(VisitBathroom.Instance())) {
	             son.GetFSM().ChangeState(VisitBathroom.Instance());
	         }
	    }

	    @Override
	    public void Exit(MinersSon son) {
	    }

	    @Override
	    public boolean OnMessage(MinersSon son, Telegram msg) {
	        SetTextColor(BACKGROUND_RED | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

	        switch (msg.Msg) {
	            case Msg_HiHoneyImHome: {
	                cout("\nMessage handled by " + GetNameOfEntity(son.ID()) + " at time: "
	                        + Clock.GetCurrentTime());

	                SetTextColor(FOREGROUND_GREEN | FOREGROUND_INTENSITY);

	                cout("\n" + GetNameOfEntity(son.ID())
	                        + ": Dad is Home!");

	                son.GetFSM().ChangeState( WashHands.Instance());
	            }

	            return true;

	        }//end switch

	        return false;
	    }

}
