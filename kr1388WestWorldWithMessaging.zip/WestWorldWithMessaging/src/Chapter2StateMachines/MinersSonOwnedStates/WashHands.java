package Chapter2StateMachines.MinersSonOwnedStates;

import static Chapter2StateMachines.EntityNames.GetNameOfEntity;
import static Chapter2StateMachines.EntityNames.ent_Miner_Bob;
import static Chapter2StateMachines.MessageDispatcher.Dispatch;
import static Chapter2StateMachines.MessageDispatcher.NO_ADDITIONAL_INFO;
import static Chapter2StateMachines.MessageDispatcher.SEND_MSG_IMMEDIATELY;
import static common.Time.CrudeTimer.Clock;
import static common.misc.ConsoleUtils.SetTextColor;
import static common.misc.ConsoleUtils.cout;
import static common.windows.BACKGROUND_RED;
import static common.windows.FOREGROUND_BLUE;
import static common.windows.FOREGROUND_GREEN;
import static common.windows.FOREGROUND_INTENSITY;
import static common.windows.FOREGROUND_RED;

import Chapter2StateMachines.MessageTypes;
import Chapter2StateMachines.MinersSon;
import Chapter2StateMachines.State;
import common.Messaging.Telegram;

public class WashHands extends State<MinersSon> {

	static final WashHands instance = new WashHands();

	private WashHands() {
	}

	// copy ctor and assignment should be private
	private WashHands(WashHands wh) {
	}

	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException("Cloning not allowed");
	}

	public static WashHands Instance() {
		return instance;
	}

	@Override
	public void Enter(MinersSon son) {
		// if not already cooking put the stew in the oven
		if (!son.Washing()) {
			cout("\n" + GetNameOfEntity(son.ID()) + ": Going to Wash hands");

			// send a delayed message myself so that I know when to take the stew
			// out of the oven
			Dispatch.DispatchMessage(1.5, // time delay
					son.ID(), // sender ID
					son.ID(), // receiver ID
					MessageTypes.Msg_ImHungry, // msg
					NO_ADDITIONAL_INFO);

			son.SetWashing(true);
		}
	}

	@Override
	public void Execute(MinersSon son) {
		cout("\n" + GetNameOfEntity(son.ID()) + ": Soap and water!");
	}

	@Override
	public void Exit(MinersSon son) {
		SetTextColor(FOREGROUND_GREEN | FOREGROUND_INTENSITY);

		cout("\n" + GetNameOfEntity(son.ID()) + ": Mama putt'n the stew on the table");
	}

	@Override
	public boolean OnMessage(MinersSon son, Telegram msg) {
		SetTextColor(BACKGROUND_RED | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);

		switch (msg.Msg) {
		case Msg_StewReady: {
			cout("\nMessage received by " + GetNameOfEntity(son.ID()) + " at time: " + Clock.GetCurrentTime());

			SetTextColor(FOREGROUND_GREEN | FOREGROUND_INTENSITY);
			cout("\n" + GetNameOfEntity(son.ID()) + ": I'm hungry! Lets eat");

			// let hubby know the stew is ready
			Dispatch.DispatchMessage(SEND_MSG_IMMEDIATELY, son.ID(), ent_Miner_Bob.id, MessageTypes.Msg_StewReady,
					NO_ADDITIONAL_INFO);

			son.SetWashing(false);

			son.GetFSM().ChangeState(DoHouseWork.Instance());
		}

			return true;

		}// end switch

		return false;
	}
}
