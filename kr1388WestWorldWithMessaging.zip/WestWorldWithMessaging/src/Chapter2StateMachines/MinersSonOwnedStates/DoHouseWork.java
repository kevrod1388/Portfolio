/**
 * @author Petr (http://www.sallyx.org/)
 */
package Chapter2StateMachines.MinersSonOwnedStates;

import static Chapter2StateMachines.EntityNames.GetNameOfEntity;
import static common.misc.ConsoleUtils.cout;
import static common.misc.utils.RandInt;

import Chapter2StateMachines.MinersSon;
import Chapter2StateMachines.State;
import common.Messaging.Telegram;

public class DoHouseWork extends State<MinersSon> {

	static final DoHouseWork instance = new DoHouseWork();

	private DoHouseWork() {
	}

	// copy ctor and assignment should be private
	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException("Cloning not allowed");
	}

	public static DoHouseWork Instance() {
		return instance;
	}

	@Override
	public void Enter(MinersSon son) {
		cout("\n" + GetNameOfEntity(son.ID()) + ": Time to do some more housework!");
	}

	@Override
	public void Execute(MinersSon son) {
		switch (RandInt(0, 2)) {
		case 0:
			cout("\n" + GetNameOfEntity(son.ID()) + ": Taking out the trash");
			break;
		case 1:
			cout("\n" + GetNameOfEntity(son.ID()) + ": Mopping the floor");
			break;
		case 2:
			cout("\n" + GetNameOfEntity(son.ID()) + ": Clean'n my room!");
			break;
		}
	}

	@Override
	public void Exit(MinersSon son) {
	}

	@Override
	public boolean OnMessage(MinersSon son, Telegram msg) {
		return false;
	}
}