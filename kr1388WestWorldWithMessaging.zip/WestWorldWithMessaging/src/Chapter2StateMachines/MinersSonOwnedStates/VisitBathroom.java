/**
 * @author Petr (http://www.sallyx.org/)
 */
package Chapter2StateMachines.MinersSonOwnedStates;

import static Chapter2StateMachines.EntityNames.GetNameOfEntity;
import static common.misc.ConsoleUtils.cout;

import Chapter2StateMachines.MinersSon;
import Chapter2StateMachines.State;
import common.Messaging.Telegram;

public class VisitBathroom extends State<MinersSon> {

	static final VisitBathroom instance = new VisitBathroom();

	private VisitBathroom() {
	}

	// copy ctor and assignment should be private
	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException("Cloning not allowed");
	}

	public static VisitBathroom Instance() {
		return instance;
	}

	@Override
	public void Enter(MinersSon son) {
		cout("\n" + GetNameOfEntity(son.ID()) + ": Gee golly I need to pee");
	}

	@Override
	public void Execute(MinersSon son) {
		cout("\n" + GetNameOfEntity(son.ID()) + ": Lovely!!");
		son.GetFSM().RevertToPreviousState();
	}

	@Override
	public void Exit(MinersSon son) {
		cout("\n" + GetNameOfEntity(son.ID()) + ": Heding back");
	}

	@Override
	public boolean OnMessage(MinersSon son, Telegram msg) {
		return false;
	}
}
