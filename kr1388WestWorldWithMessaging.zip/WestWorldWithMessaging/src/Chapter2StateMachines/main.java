/**
 * @author Petr (http://www.sallyx.org/)
 */
package Chapter2StateMachines;

import static Chapter2StateMachines.EntityManager.EntityMgr;
import static Chapter2StateMachines.MessageDispatcher.Dispatch;
import static common.misc.ConsoleUtils.PressAnyKeyToContinue;
import static common.misc.ConsoleUtils.enableSwing;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class main {

	public static void main(String[] args) throws InterruptedException, FileNotFoundException {
		// define this to send output to a text file (see locations.h)
		PrintStream out = System.out;
		if (location_type.TEXTOUTPUT) {
			System.setOut(new PrintStream(new FileOutputStream(new File("output.txt"))));
		} else {
			// send output to swing component instead of console
			enableSwing();
		}

		// create a miner
		Miner Bob = new Miner(EntityNames.ent_Miner_Bob);

		// create his wife
		MinersWife Elsa = new MinersWife(EntityNames.ent_Elsa);

		MinersSon son = new MinersSon(EntityNames.ent_Little_Bob);

		// register them with the entity manager
		EntityMgr.RegisterEntity(Bob);
		EntityMgr.RegisterEntity(Elsa);
		EntityMgr.RegisterEntity(son);

		// simply run the miner through a few Update calls
		for (int i = 0; i < 30; ++i) {
			Bob.Update();
			Elsa.Update();
			son.Update();

			// dispatch any delayed messages
			Dispatch.DispatchDelayedMessages();

			Thread.sleep(800);
		}
		Bob = null;
		Elsa = null;
		son = null;
//*/        
		if (location_type.TEXTOUTPUT) {
			System.setOut(out);
		}
		// wait for a keypress (enter) before exiting
		PressAnyKeyToContinue();
	}
}
