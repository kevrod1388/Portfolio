package movies.txstate.edu.moviesskeleton;

import java.util.ArrayList;

public class PopularMovies {
    private static PopularMovies popularMovies = new PopularMovies();
    private ArrayList<Movie> movies;

    PopularMovies(){
        movies = new ArrayList<>();
    }

    public static PopularMovies getInstance(){
        return popularMovies;
    }

    public ArrayList<Movie> getMovies() {
        return movies;
    }

    public Movie getMovie(int index){
        return movies.get(index);
    }

    public void clear(){
        movies.clear();
    }

    public int size(){
        return movies.size();
    }

    public void add(Movie movie){
        movies.add(movie);
    }
}
