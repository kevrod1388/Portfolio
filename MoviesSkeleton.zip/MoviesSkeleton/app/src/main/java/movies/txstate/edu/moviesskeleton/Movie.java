package movies.txstate.edu.moviesskeleton;

public class Movie {
    private int id;
    private String title;
    private String releaseYear;
    private String rating;
    private String overview;
    private String posterPath;

    public Movie(int id, String title, String rating, String releaseYear, String overview, String posterPath) {
        this.id = id;
        this.title = title;
        this.rating = rating;
        this.releaseYear = releaseYear;
        this.overview = overview;
        this.posterPath = posterPath;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getReleaseYear() {
        return releaseYear;
    }

    public String getOverview() {
        return overview;
    }

    public String getPosterPath() {
        return posterPath;
    }

    public String getRating() {
        return rating;
    }

    @Override
    public String toString() {
        return title+" ("+releaseYear+"): "+overview;
    }
}
